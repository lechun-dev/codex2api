param(
    [string]$ProviderName = "",
    [string]$CodexHome = (Join-Path $env:USERPROFILE ".codex")
)

$ErrorActionPreference = "Stop"

$ScriptDir = $PSScriptRoot
$ToolkitRoot = Split-Path -Parent $ScriptDir
$RepairScript = Join-Path $ScriptDir "repair-codex-history-provider.mjs"
$SqliteBin = Join-Path $ToolkitRoot "tools\sqlite3.exe"

function Find-Node {
    $candidates = @()
    if (-not [string]::IsNullOrWhiteSpace($env:NODE_BIN)) {
        $candidates += $env:NODE_BIN
    }
    if ($env:ProgramFiles) {
        $candidates += Join-Path $env:ProgramFiles "nodejs\node.exe"
    }
    if (${env:ProgramFiles(x86)}) {
        $candidates += Join-Path ${env:ProgramFiles(x86)} "nodejs\node.exe"
    }
    if ($env:LOCALAPPDATA) {
        $candidates += Join-Path $env:LOCALAPPDATA "Programs\Codex\resources\cua_node\bin\node.exe"
        $candidates += Join-Path $env:LOCALAPPDATA "Programs\Codex\resources\cua_node\node.exe"
    }
    $candidates += @("node.exe", "node")

    foreach ($candidate in $candidates) {
        if ([string]::IsNullOrWhiteSpace($candidate)) {
            continue
        }
        if (Test-Path -LiteralPath $candidate) {
            return $candidate
        }
        try {
            $cmd = Get-Command $candidate -ErrorAction Stop
            return $cmd.Source
        } catch {
        }
    }
    return $null
}

function Invoke-Node {
    param(
        [Parameter(Mandatory = $true)][string]$Node,
        [Parameter(Mandatory = $true)][string[]]$Arguments
    )

    & $Node @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Node command failed with exit code $LASTEXITCODE"
    }
}

$Node = Find-Node
if (-not $Node) {
    throw "Node.js was not found. Install Node.js LTS, then run this tool again."
}

if (-not (Test-Path -LiteralPath $RepairScript)) {
    throw "Required file not found: $RepairScript"
}

if (-not (Test-Path -LiteralPath $CodexHome)) {
    throw "Codex home not found: $CodexHome"
}

$commonArgs = @($RepairScript, "--codex-home", $CodexHome, "--sqlite-bin", $SqliteBin)
if (-not [string]::IsNullOrWhiteSpace($ProviderName)) {
    $commonArgs += @("--provider", $ProviderName.Trim())
}

Write-Host "Codex home: $CodexHome"
Write-Host "Close Codex Desktop before applying repair."
Write-Host ""
Write-Host "Dry-run: history repair plan"
Invoke-Node -Node $Node -Arguments $commonArgs

Write-Host ""
$confirm = Read-Host 'Type REPAIR to apply'
if ($confirm -ne "REPAIR") {
    Write-Host "Canceled."
    exit 0
}

Write-Host ""
Write-Host "Applying history repair..."
Invoke-Node -Node $Node -Arguments ($commonArgs + @("--apply", "--yes"))

Write-Host ""
Write-Host "History repair finished. Restart Codex Desktop."
