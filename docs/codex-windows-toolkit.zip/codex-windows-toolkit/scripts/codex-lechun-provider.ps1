param(
    [string]$BaseUrl = "https://codexapi.lechun.cc",
    [string]$Model = "gpt-5.5",
    [string]$ReasoningEffort = "high",
    [string]$CodexHome = (Join-Path $env:USERPROFILE ".codex")
)

$ErrorActionPreference = "Stop"

$ProviderName = "lechun"
$ScriptDir = $PSScriptRoot
$ToolkitRoot = Split-Path -Parent $ScriptDir
$ConfigureScript = Join-Path $ScriptDir "configure-lechun-provider.mjs"
$RepairScript = Join-Path $ScriptDir "repair-codex-history-provider.mjs"
$SqliteBin = Join-Path $ToolkitRoot "tools\sqlite3.exe"

function Find-Node {
    $candidates = @()
    if (-not [string]::IsNullOrWhiteSpace($env:NODE_BIN)) {
        $candidates += $env:NODE_BIN
    }
    if ($env:ProgramFiles) {
        $candidates += Join-Path $env:ProgramFiles "nodejs\node.exe"
    }
    if (${env:ProgramFiles(x86)}) {
        $candidates += Join-Path ${env:ProgramFiles(x86)} "nodejs\node.exe"
    }
    if ($env:LOCALAPPDATA) {
        $candidates += Join-Path $env:LOCALAPPDATA "Programs\Codex\resources\cua_node\bin\node.exe"
        $candidates += Join-Path $env:LOCALAPPDATA "Programs\Codex\resources\cua_node\node.exe"
    }
    $candidates += @("node.exe", "node")

    foreach ($candidate in $candidates) {
        if ([string]::IsNullOrWhiteSpace($candidate)) {
            continue
        }
        if (Test-Path -LiteralPath $candidate) {
            return $candidate
        }
        try {
            $cmd = Get-Command $candidate -ErrorAction Stop
            return $cmd.Source
        } catch {
        }
    }
    return $null
}

function Require-File {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "Required file not found: $Path"
    }
}

function Invoke-Node {
    param(
        [Parameter(Mandatory = $true)][string]$Node,
        [Parameter(Mandatory = $true)][string[]]$Arguments
    )

    & $Node @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Node command failed with exit code $LASTEXITCODE"
    }
}

$Node = Find-Node
if (-not $Node) {
    throw "Node.js was not found. Install Node.js LTS, then run this tool again."
}

Require-File -Path $ConfigureScript
Require-File -Path $RepairScript

if (-not (Test-Path -LiteralPath $CodexHome)) {
    throw "Codex home not found: $CodexHome"
}

Write-Host "Codex home: $CodexHome"
Write-Host "Provider: $ProviderName"
Write-Host "Close Codex Desktop before applying changes."
Write-Host ""

$secureKey = Read-Host "Enter Lechun API key" -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
try {
    $ApiKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
}

if ([string]::IsNullOrWhiteSpace($ApiKey)) {
    throw "API key cannot be empty."
}

$oldApiKey = $env:LECHUN_API_KEY
$oldOperationId = $env:CODEX_TOOLKIT_OPERATION_ID
$env:LECHUN_API_KEY = $ApiKey
$env:CODEX_TOOLKIT_OPERATION_ID = ((Get-Date -Format "yyyyMMddHHmmss") + "-lechun-provider")

try {
    Write-Host ""
    Write-Host "Dry-run: provider configuration plan"
    Invoke-Node -Node $Node -Arguments @(
        $ConfigureScript,
        "--codex-home", $CodexHome,
        "--provider", $ProviderName,
        "--base-url", $BaseUrl,
        "--model", $Model,
        "--reasoning", $ReasoningEffort
    )

    Write-Host ""
    Write-Host "Dry-run: history repair plan"
    Invoke-Node -Node $Node -Arguments @(
        $RepairScript,
        "--codex-home", $CodexHome,
        "--provider", $ProviderName,
        "--sqlite-bin", $SqliteBin
    )

    Write-Host ""
    Write-Host "Apply mode will first create a full Codex home snapshot under:"
    Write-Host "  $env:USERPROFILE\CodexBackups"
    Write-Host "Then it will write config.toml and repair history provider metadata."
    $confirm = Read-Host 'Type CONFIGURE to apply'
    if ($confirm -ne "CONFIGURE") {
        Write-Host "Canceled."
        exit 0
    }

    Write-Host ""
    Write-Host "Applying provider configuration..."
    Invoke-Node -Node $Node -Arguments @(
        $ConfigureScript,
        "--codex-home", $CodexHome,
        "--provider", $ProviderName,
        "--base-url", $BaseUrl,
        "--model", $Model,
        "--reasoning", $ReasoningEffort,
        "--apply",
        "--yes"
    )

    Write-Host ""
    Write-Host "Applying history repair..."
    Invoke-Node -Node $Node -Arguments @(
        $RepairScript,
        "--codex-home", $CodexHome,
        "--provider", $ProviderName,
        "--sqlite-bin", $SqliteBin,
        "--apply",
        "--yes"
    )
} finally {
    if ($null -eq $oldApiKey) {
        Remove-Item Env:\LECHUN_API_KEY -ErrorAction SilentlyContinue
    } else {
        $env:LECHUN_API_KEY = $oldApiKey
    }

    if ($null -eq $oldOperationId) {
        Remove-Item Env:\CODEX_TOOLKIT_OPERATION_ID -ErrorAction SilentlyContinue
    } else {
        $env:CODEX_TOOLKIT_OPERATION_ID = $oldOperationId
    }
}

Write-Host ""
Write-Host "Done. Restart Codex Desktop."
Write-Host "Do not share config.toml or files under CodexBackups; they contain private auth/config data."
