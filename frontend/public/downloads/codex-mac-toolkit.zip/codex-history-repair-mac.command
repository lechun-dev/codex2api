#!/bin/bash
set -euo pipefail

CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"
BACKUP_SUFFIX="before-history-repair"
TIMESTAMP="$(date +%Y%m%d%H%M%S)"

PYTHON_BIN="${PYTHON_BIN:-}"
if [ -z "$PYTHON_BIN" ]; then
  if command -v python3 >/dev/null 2>&1; then
    PYTHON_BIN="$(command -v python3)"
  elif command -v python >/dev/null 2>&1; then
    PYTHON_BIN="$(command -v python)"
  else
    echo "Python was not found on this Mac."
    echo "Please install Python 3, then run this tool again."
    echo
    read -r -p "Press Enter to close..."
    exit 1
  fi
fi

if [ ! -d "$CODEX_HOME" ]; then
  echo "Codex home not found: $CODEX_HOME"
  echo
  read -r -p "Press Enter to close..."
  exit 1
fi

export CODEX_HOME BACKUP_SUFFIX TIMESTAMP
"$PYTHON_BIN" <<'PY'
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
from pathlib import Path

codex_home = Path(os.environ["CODEX_HOME"]).expanduser()
backup_suffix = os.environ["BACKUP_SUFFIX"]
timestamp = os.environ["TIMESTAMP"]
config_path = codex_home / "config.toml"
auth_path = codex_home / "auth.json"

def stat_signature(path: Path):
    if not path.exists():
        return None
    st = path.stat()
    return (st.st_size, st.st_mtime_ns)

def backup_file(path: Path):
    if path.exists():
        backup = Path(f"{path}.{timestamp}.{backup_suffix}.bak")
        shutil.copy2(path, backup)
        print(f"Backup: {backup}")

def backup_sqlite(path: Path):
    backup_file(path)
    backup_file(Path(str(path) + "-shm"))
    backup_file(Path(str(path) + "-wal"))

def detect_provider():
    if not config_path.exists():
        return None
    text = config_path.read_text(encoding="utf-8")
    match = re.search(r'(?m)^\s*model_provider\s*=\s*"([^"]+)"', text)
    return match.group(1) if match else None

def prompt_provider():
    detected = detect_provider()
    if detected:
        answer = input(f"Detected provider '{detected}'. Press Enter to use it, or type another provider: ").strip()
        return answer or detected
    return input("Enter current model_provider name, for example lechun or custom: ").strip()

def repair_config():
    if not config_path.exists():
        print(f"Warning: config.toml not found, skipped config repair: {config_path}")
        return

    backup_file(config_path)
    text = config_path.read_text(encoding="utf-8")
    text = re.sub(r"(?m)^\s*disable_response_storage\s*=\s*true\s*(?:#.*)?\r?\n?", "", text)

    match = re.search(r"(?ms)^\[history\]\r?\n.*?(?=^\[|\Z)", text)
    if match:
        section = match.group(0)
        if re.search(r"(?m)^persistence\s*=", section):
            updated = re.sub(r"(?m)^persistence\s*=.*$", 'persistence = "save-all"', section, count=1)
        else:
            updated = section.rstrip() + '\npersistence = "save-all"\n'
        text = text[:match.start()] + updated + text[match.end():]
    else:
        text = text.rstrip() + '\n\n[history]\npersistence = "save-all"\n'

    config_path.write_text(text.rstrip() + "\n", encoding="utf-8")
    print(f"Config history persistence repaired: {config_path}")

def update_jsonl_provider(path: Path, provider: str):
    if not path.exists():
        return

    backup_file(path)
    changed = False
    out = []

    with path.open("r", encoding="utf-8") as inp:
        for line in inp:
            raw = line.rstrip("\n")
            if '"session_meta"' not in raw:
                out.append(raw)
                continue

            if re.search(r'"model_provider"\s*:', raw):
                new_raw = re.sub(r'"model_provider"\s*:\s*"[^"]*"', f'"model_provider":"{provider}"', raw, count=1)
                changed = changed or new_raw != raw
                out.append(new_raw)
                continue

            try:
                obj = json.loads(raw)
                if obj.get("type") == "session_meta" and isinstance(obj.get("payload"), dict):
                    obj["payload"]["model_provider"] = provider
                    out.append(json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
                    changed = True
                elif isinstance(obj.get("session_meta"), dict):
                    obj["session_meta"]["model_provider"] = provider
                    out.append(json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
                    changed = True
                else:
                    out.append(raw)
            except Exception:
                out.append(raw)

    if changed:
        path.write_text("\n".join(out) + "\n", encoding="utf-8")
        print(f"Updated rollout provider: {path}")
    else:
        print(f"No provider change needed: {path}")

def short_title(text):
    if not text:
        return None
    title = re.sub(r"\s+", " ", str(text)).strip()
    return title[:64] if title else None

def existing_index_names():
    names = {}
    index = codex_home / "session_index.jsonl"
    if not index.exists():
        return names

    with index.open("r", encoding="utf-8") as inp:
        for line in inp:
            try:
                obj = json.loads(line)
                if obj.get("id") and obj.get("thread_name"):
                    names[obj["id"]] = obj["thread_name"]
            except Exception:
                pass
    return names

def read_rollout_summary(path: Path, names):
    thread_id = None
    created_at = None
    updated_at = None
    title = None

    with path.open("r", encoding="utf-8") as inp:
        for raw in inp:
            line = raw.rstrip("\n")
            match = re.search(r'"timestamp"\s*:\s*"([^"]+)"', line)
            if match and (updated_at is None or match.group(1) > updated_at):
                updated_at = match.group(1)

            if thread_id is None and '"session_meta"' in line:
                try:
                    obj = json.loads(line)
                    if obj.get("type") == "session_meta" and isinstance(obj.get("payload"), dict):
                        thread_id = obj["payload"].get("id")
                        created_at = obj["payload"].get("timestamp")
                    elif isinstance(obj.get("session_meta"), dict):
                        thread_id = obj["session_meta"].get("id")
                        created_at = obj["session_meta"].get("timestamp")
                except Exception:
                    pass

            if title is None and ('"user_message"' in line or re.search(r'"role"\s*:\s*"user"', line)):
                try:
                    obj = json.loads(line)
                    if obj.get("type") == "event_msg" and isinstance(obj.get("payload"), dict) and obj["payload"].get("type") == "user_message":
                        title = short_title(obj["payload"].get("message"))
                    elif obj.get("type") == "response_item" and isinstance(obj.get("payload"), dict) and obj["payload"].get("role") == "user":
                        for item in obj["payload"].get("content", []):
                            if isinstance(item, dict):
                                title = short_title(item.get("text") or item.get("input_text"))
                                if title:
                                    break
                except Exception:
                    pass

    if not thread_id:
        return None

    if thread_id in names:
        title = names[thread_id]
    if not title:
        title = f"Recovered thread {thread_id[:8]}"
    if not updated_at:
        updated_at = created_at or path.stat().st_mtime_ns

    return {"id": thread_id, "thread_name": title, "updated_at": updated_at}

def rebuild_session_index():
    names = existing_index_names()
    records = {}

    for root in [codex_home / "sessions", codex_home / "archived_sessions"]:
        if not root.exists():
            continue
        for path in root.rglob("*.jsonl"):
            summary = read_rollout_summary(path, names)
            if not summary:
                continue
            current = records.get(summary["id"])
            if current is None or str(summary["updated_at"]) > str(current["updated_at"]):
                records[summary["id"]] = summary

    if not records:
        print("Warning: no rollout sessions found, skipped session_index rebuild.")
        return

    index = codex_home / "session_index.jsonl"
    backup_file(index)
    lines = [json.dumps(item, ensure_ascii=False, separators=(",", ":")) for item in sorted(records.values(), key=lambda x: str(x["updated_at"]))]
    index.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Rebuilt session index: {index} ({len(records)} threads)")

def update_state_db(path: Path, provider: str):
    if not path.exists():
        return

    try:
        conn = sqlite3.connect(str(path))
        try:
            table = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='threads'").fetchone()
            if not table:
                print(f"Warning: no threads table found, skipped DB provider repair: {path}")
                return
        finally:
            conn.close()
    except Exception as exc:
        print(f"Warning: cannot inspect DB, skipped DB provider repair: {path}: {exc}")
        return

    backup_sqlite(path)

    sqlite_cli = shutil.which("sqlite3")
    if sqlite_cli is None and Path("/usr/bin/sqlite3").exists():
        sqlite_cli = "/usr/bin/sqlite3"

    if sqlite_cli:
        escaped = provider.replace("'", "''")
        try:
            subprocess.run([sqlite_cli, str(path), f"UPDATE threads SET model_provider = '{escaped}';"], check=True)
            print(f"Updated SQLite provider with sqlite3: {path}")
            return
        except Exception as exc:
            print(f"Warning: sqlite3 command failed, falling back to Python sqlite3: {exc}")

    conn = sqlite3.connect(str(path))
    try:
        conn.execute("UPDATE threads SET model_provider = ? WHERE model_provider IS NULL OR model_provider <> ?", (provider, provider))
        conn.commit()
    finally:
        conn.close()
    print(f"Updated SQLite provider: {path}")

auth_before = stat_signature(auth_path)
provider = prompt_provider()
if not provider:
    print("Provider cannot be empty.")
    sys.exit(1)

print(f"Codex home: {codex_home}")
print(f"Target provider: {provider}")
print()
print("Close Codex Desktop before continuing.")
confirm = input("Type REPAIR to continue: ")
if confirm != "REPAIR":
    print("Canceled.")
    sys.exit(0)

repair_config()

for target in [codex_home / "session_index.jsonl"]:
    update_jsonl_provider(target, provider)
for root in [codex_home / "sessions", codex_home / "archived_sessions"]:
    if root.exists():
        for target in root.rglob("*.jsonl"):
            update_jsonl_provider(target, provider)

rebuild_session_index()
update_state_db(codex_home / "state_5.sqlite", provider)
update_state_db(codex_home / "sqlite" / "state_5.sqlite", provider)

auth_after = stat_signature(auth_path)
if auth_before != auth_after:
    print(f"auth.json changed unexpectedly: {auth_path}")
    sys.exit(1)

print()
print("History repair finished. Restart Codex Desktop.")
print(f"Backups were created with suffix: {backup_suffix}")
PY

echo
read -r -p "Press Enter to close..."
