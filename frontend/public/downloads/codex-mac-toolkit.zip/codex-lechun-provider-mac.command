#!/bin/bash
set -euo pipefail

PROVIDER_NAME="lechun"
BASE_URL="${BASE_URL:-https://codexapi.lechun.cc}"
MODEL="${MODEL:-gpt-5.5}"
REASONING_EFFORT="${REASONING_EFFORT:-high}"
CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"
CONFIG_PATH="$CODEX_HOME/config.toml"
AUTH_PATH="$CODEX_HOME/auth.json"
TIMESTAMP="$(date +%Y%m%d%H%M%S)"

PYTHON_BIN="${PYTHON_BIN:-}"
if [ -z "$PYTHON_BIN" ]; then
  if command -v python3 >/dev/null 2>&1; then
    PYTHON_BIN="$(command -v python3)"
  elif command -v python >/dev/null 2>&1; then
    PYTHON_BIN="$(command -v python)"
  else
    echo "Python was not found on this Mac."
    echo "Please install Python 3, then run this tool again."
    echo
    read -r -p "Press Enter to close..."
    exit 1
  fi
fi

backup_file() {
  local path="$1"
  local suffix="$2"

  if [ -f "$path" ]; then
    local backup_path="${path}.${TIMESTAMP}.${suffix}.bak"
    cp -p "$path" "$backup_path"
    echo "Backup: $backup_path"
  fi
}

stat_signature() {
  local path="$1"

  if [ ! -f "$path" ]; then
    echo "missing"
    return
  fi

  stat -f "%z %m" "$path"
}

if [ ! -d "$CODEX_HOME" ]; then
  echo "Codex home not found: $CODEX_HOME"
  echo
  read -r -p "Press Enter to close..."
  exit 1
fi

if [ ! -f "$CONFIG_PATH" ]; then
  echo "Config not found: $CONFIG_PATH"
  echo
  read -r -p "Press Enter to close..."
  exit 1
fi

echo "Codex home: $CODEX_HOME"
echo "Provider: $PROVIDER_NAME"
echo "Base URL: $BASE_URL"
echo

printf "Enter Lechun API key: "
stty -echo
IFS= read -r API_KEY
stty echo
printf "\n"

if [ -z "${API_KEY// }" ]; then
  echo "API key cannot be empty."
  echo
  read -r -p "Press Enter to close..."
  exit 1
fi

AUTH_BEFORE="$(stat_signature "$AUTH_PATH")"
backup_file "$CONFIG_PATH" "before-provider-lechun"

export PROVIDER_NAME BASE_URL MODEL REASONING_EFFORT CONFIG_PATH API_KEY
"$PYTHON_BIN" <<'PY'
import os
import re
from pathlib import Path

provider = os.environ["PROVIDER_NAME"]
base_url = os.environ["BASE_URL"]
model = os.environ["MODEL"]
reasoning = os.environ["REASONING_EFFORT"]
config_path = Path(os.environ["CONFIG_PATH"])
api_key = os.environ["API_KEY"]

content = config_path.read_text(encoding="utf-8")

def remove_section(text: str, section: str) -> str:
    escaped = re.escape(section)
    return re.sub(rf"(?ms)^\[{escaped}\]\r?\n.*?(?=^\[|\Z)", "", text)

def set_top_level(text: str, key: str, value: str) -> str:
    line = f'{key} = "{value}"'
    pattern = rf"(?m)^{re.escape(key)}\s*=.*$"
    if re.search(pattern, text):
        return re.sub(pattern, line, text, count=1)

    first_section = re.search(r"(?m)^\[", text)
    if first_section:
        return text[:first_section.start()] + line + "\n" + text[first_section.start():]

    return text.rstrip() + "\n" + line + "\n"

def ensure_history(text: str) -> str:
    match = re.search(r"(?ms)^\[history\]\r?\n.*?(?=^\[|\Z)", text)
    if match:
        section = match.group(0)
        if re.search(r"(?m)^persistence\s*=", section):
            updated = re.sub(r"(?m)^persistence\s*=.*$", 'persistence = "save-all"', section, count=1)
        else:
            updated = section.rstrip() + '\npersistence = "save-all"\n'
        return text[:match.start()] + updated + text[match.end():]

    return text.rstrip() + '\n\n[history]\npersistence = "save-all"\n'

content = remove_section(content, f"model_providers.{provider}")
content = set_top_level(content, "model_provider", provider)
content = set_top_level(content, "model", model)
content = set_top_level(content, "model_reasoning_effort", reasoning)
content = ensure_history(content)

provider_block = f'''
[model_providers.{provider}]
name = "{provider}"
wire_api = "responses"
requires_openai_auth = true
base_url = "{base_url}"
experimental_bearer_token = "{api_key}"
'''

config_path.write_text(content.rstrip() + "\n" + provider_block.lstrip(), encoding="utf-8")
print(f"Updated config: {config_path}")
PY

update_jsonl_provider() {
  local path="$1"

  if [ ! -f "$path" ]; then
    return
  fi

  backup_file "$path" "before-provider-lechun"

  PROVIDER_NAME="$PROVIDER_NAME" JSONL_PATH="$path" "$PYTHON_BIN" <<'PY'
import json
import os
import tempfile
from pathlib import Path

provider = os.environ["PROVIDER_NAME"]
path = Path(os.environ["JSONL_PATH"])
fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))

with os.fdopen(fd, "w", encoding="utf-8") as out:
    with path.open("r", encoding="utf-8") as inp:
        for line in inp:
            raw = line.rstrip("\n")
            if not raw.strip():
                out.write(line)
                continue
            try:
                obj = json.loads(raw)
                session_meta = obj.get("session_meta")
                if isinstance(session_meta, dict) and "model_provider" in session_meta:
                    session_meta["model_provider"] = provider
                    out.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")
                else:
                    out.write(line)
            except Exception:
                out.write(line)

os.replace(tmp_name, path)
print(f"Updated session meta provider: {path}")
PY
}

update_sqlite_provider() {
  local path="$1"

  if [ ! -f "$path" ]; then
    return
  fi

  if ! command -v sqlite3 >/dev/null 2>&1; then
    backup_file "$path" "before-provider-lechun"
    PROVIDER_NAME="$PROVIDER_NAME" SQLITE_PATH="$path" "$PYTHON_BIN" <<'PY'
import os
import sqlite3

provider = os.environ["PROVIDER_NAME"]
path = os.environ["SQLITE_PATH"]

conn = sqlite3.connect(path)
try:
    table = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='threads'").fetchone()
    if not table:
        print(f"Warning: no threads table found, skipped DB provider migration: {path}")
    else:
        conn.execute("UPDATE threads SET model_provider = ?", (provider,))
        conn.commit()
        print(f"Updated SQLite provider with Python sqlite3: {path}")
finally:
    conn.close()
PY
    return
  fi

  backup_file "$path" "before-provider-lechun"
  sqlite3 "$path" "UPDATE threads SET model_provider = '$PROVIDER_NAME';"
  echo "Updated SQLite provider: $path"
}

if [ "${SKIP_HISTORY_PROVIDER_MIGRATION:-0}" != "1" ]; then
  update_jsonl_provider "$CODEX_HOME/session_index.jsonl"

  if [ -d "$CODEX_HOME/sessions" ]; then
    while IFS= read -r -d '' file; do
      update_jsonl_provider "$file"
    done < <(find "$CODEX_HOME/sessions" -type f -name "*.jsonl" -print0)
  fi

  if [ -d "$CODEX_HOME/archived_sessions" ]; then
    while IFS= read -r -d '' file; do
      update_jsonl_provider "$file"
    done < <(find "$CODEX_HOME/archived_sessions" -type f -name "*.jsonl" -print0)
  fi

  update_sqlite_provider "$CODEX_HOME/state_5.sqlite"
  update_sqlite_provider "$CODEX_HOME/sqlite/state_5.sqlite"
fi

AUTH_AFTER="$(stat_signature "$AUTH_PATH")"
if [ "$AUTH_BEFORE" != "$AUTH_AFTER" ]; then
  echo "auth.json changed unexpectedly: $AUTH_PATH"
  echo
  read -r -p "Press Enter to close..."
  exit 1
fi

echo
echo "Done. Provider name is now '$PROVIDER_NAME'."
echo "Restart Codex Desktop after this window closes."
echo "Do not share config.toml because it now contains your API key."
echo
read -r -p "Press Enter to close..."
