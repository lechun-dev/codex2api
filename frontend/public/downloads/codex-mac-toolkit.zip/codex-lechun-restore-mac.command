#!/bin/bash
set -euo pipefail

CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"
AUTH_PATH="$CODEX_HOME/auth.json"
BACKUP_SUFFIX="before-provider-lechun"
RESTORE_SUFFIX="before-restore-lechun"
TIMESTAMP="$(date +%Y%m%d%H%M%S)"

PYTHON_BIN="${PYTHON_BIN:-}"
if [ -z "$PYTHON_BIN" ]; then
  if command -v python3 >/dev/null 2>&1; then
    PYTHON_BIN="$(command -v python3)"
  elif command -v python >/dev/null 2>&1; then
    PYTHON_BIN="$(command -v python)"
  else
    echo "Python was not found on this Mac."
    echo "Please install Python 3, then run this tool again."
    echo
    read -r -p "Press Enter to close..."
    exit 1
  fi
fi

stat_signature() {
  local path="$1"

  if [ ! -f "$path" ]; then
    echo "missing"
    return
  fi

  stat -f "%z %m" "$path"
}

if [ ! -d "$CODEX_HOME" ]; then
  echo "Codex home not found: $CODEX_HOME"
  echo
  read -r -p "Press Enter to close..."
  exit 1
fi

AUTH_BEFORE="$(stat_signature "$AUTH_PATH")"

export CODEX_HOME BACKUP_SUFFIX RESTORE_SUFFIX TIMESTAMP
"$PYTHON_BIN" <<'PY'
import os
import re
import shutil
import sys
from pathlib import Path

codex_home = Path(os.environ["CODEX_HOME"])
backup_suffix = os.environ["BACKUP_SUFFIX"]
restore_suffix = os.environ["RESTORE_SUFFIX"]
timestamp = os.environ["TIMESTAMP"]
pattern = re.compile(rf"^(?P<path>.+)\.(?P<timestamp>\d{{14}})\.{re.escape(backup_suffix)}\.bak$")

latest = {}
for backup in codex_home.rglob(f"*.{backup_suffix}.bak"):
    match = pattern.match(str(backup))
    if not match:
        continue

    original = Path(match.group("path"))
    backup_ts = match.group("timestamp")
    current = latest.get(original)
    if current is None or backup_ts > current[0]:
        latest[original] = (backup_ts, backup)

if not latest:
    print(f"No backups found with suffix: {backup_suffix}")
    sys.exit(1)

print("The following files will be restored from latest backups:")
for original in sorted(latest):
    print(f"  {original}")
    print(f"    <- {latest[original][1]}")
print()

confirm = input("Type RESTORE to continue: ")
if confirm != "RESTORE":
    print("Canceled.")
    sys.exit(0)

for original in sorted(latest):
    _, backup = latest[original]
    original.parent.mkdir(parents=True, exist_ok=True)

    if original.exists():
        current_backup = Path(f"{original}.{timestamp}.{restore_suffix}.bak")
        shutil.copy2(original, current_backup)
        print(f"Current backup: {current_backup}")

    shutil.copy2(backup, original)
    print(f"Restored: {original}")
PY

AUTH_AFTER="$(stat_signature "$AUTH_PATH")"
if [ "$AUTH_BEFORE" != "$AUTH_AFTER" ]; then
  echo "auth.json changed unexpectedly: $AUTH_PATH"
  echo
  read -r -p "Press Enter to close..."
  exit 1
fi

echo
echo "Restore finished. Restart Codex Desktop."
echo
read -r -p "Press Enter to close..."
