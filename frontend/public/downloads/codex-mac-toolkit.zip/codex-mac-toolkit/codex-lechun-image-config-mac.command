#!/bin/bash
set -euo pipefail

TOOL_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIGURE_SCRIPT="$TOOL_DIR/configure-lechun-provider.mjs"
CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"
NODE_BIN="${NODE_BIN:-}"

pause() {
  echo
  read -r -p "Press Enter to close..."
}

if [ ! -f "$CONFIGURE_SCRIPT" ] || [ ! -d "$CODEX_HOME" ]; then
  echo "Toolkit script or Codex home was not found."
  pause
  exit 1
fi

if [ -z "$NODE_BIN" ]; then
  if command -v node >/dev/null 2>&1; then
    NODE_BIN="$(command -v node)"
  elif [ -x "/Applications/Codex.app/Contents/Resources/cua_node/bin/node" ]; then
    NODE_BIN="/Applications/Codex.app/Contents/Resources/cua_node/bin/node"
  else
    echo "Node.js was not found."
    pause
    exit 1
  fi
fi

echo "Codex Lechun image generation setup"
echo "This only configures image generation and does not change provider or history."
printf "Enter Lechun API key: "
stty -echo
IFS= read -r LECHUN_API_KEY
stty echo
printf "\n"

if [ -z "${LECHUN_API_KEY// }" ]; then
  echo "API key cannot be empty."
  pause
  exit 1
fi
export LECHUN_API_KEY

"$NODE_BIN" "$CONFIGURE_SCRIPT" --codex-home "$CODEX_HOME" --image-env-only
echo
echo "Type CONFIGURE to save the image generation settings."
read -r -p "> " CONFIRM
if [ "$CONFIRM" != "CONFIGURE" ]; then
  echo "Canceled."
  pause
  exit 0
fi

"$NODE_BIN" "$CONFIGURE_SCRIPT" --codex-home "$CODEX_HOME" --image-env-only --apply --yes
unset LECHUN_API_KEY
echo
echo "Done. Fully quit and restart Codex Desktop."
pause
