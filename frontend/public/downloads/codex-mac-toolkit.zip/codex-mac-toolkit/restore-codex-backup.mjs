#!/usr/bin/env node
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import readline from 'node:readline/promises';

function usage() {
  return `Restore Codex files from toolkit manifest backups.

Usage:
  node scripts/restore-codex-backup.mjs [options]

Default mode is dry-run. No files are changed unless --apply is present.

Options:
  --codex-home <path>   Codex home directory. Defaults to CODEX_HOME or ~/.codex
  --backup-dir <path>   Backup directory containing manifest.json. Defaults to latest manifest backup
  --apply               Restore files. Without this, only prints a plan
  --yes                 Skip restore confirmation
  --help                Show this help
`;
}

function parseArgs(argv) {
  const args = {
    codexHome: process.env.CODEX_HOME || path.join(os.homedir(), '.codex'),
    backupDir: '',
    apply: false,
    yes: false,
    help: false,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--help' || arg === '-h') args.help = true;
    else if (arg === '--apply') args.apply = true;
    else if (arg === '--yes') args.yes = true;
    else if (arg === '--codex-home') args.codexHome = requireValue(argv, ++i, arg);
    else if (arg === '--backup-dir') args.backupDir = requireValue(argv, ++i, arg);
    else throw new Error(`Unknown argument: ${arg}`);
  }

  args.codexHome = path.resolve(expandHome(args.codexHome));
  if (args.backupDir) args.backupDir = path.resolve(expandHome(args.backupDir));
  return args;
}

function requireValue(argv, index, flag) {
  const value = argv[index];
  if (!value || value.startsWith('--')) throw new Error(`${flag} requires a value`);
  return value;
}

function expandHome(value) {
  if (value === '~') return os.homedir();
  if (value.startsWith('~/')) return path.join(os.homedir(), value.slice(2));
  return value;
}

function findManifestBackups(codexHome) {
  const root = path.join(codexHome, 'repair_backups');
  if (!fs.existsSync(root)) return [];
  return fs.readdirSync(root, { withFileTypes: true })
    .filter((entry) => entry.isDirectory())
    .map((entry) => path.join(root, entry.name))
    .filter((dir) => fs.existsSync(path.join(dir, 'manifest.json')))
    .map((dir) => {
      const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8'));
      return { dir, manifest, createdAt: manifest.createdAt || path.basename(dir) };
    })
    .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
}

function latestLegacyRepairBackup(codexHome) {
  const root = path.join(codexHome, 'repair_backups');
  if (!fs.existsSync(root)) return null;
  const dirs = fs.readdirSync(root, { withFileTypes: true })
    .filter((entry) => entry.isDirectory())
    .map((entry) => path.join(root, entry.name))
    .sort((a, b) => path.basename(b).localeCompare(path.basename(a)));

  for (const dir of dirs) {
    const entries = [];
    walkFiles(dir, (file) => {
      const rel = path.relative(dir, file);
      if (rel === 'manifest.json') return;
      if (file.endsWith('.backup')) {
        const withoutBackup = rel.slice(0, -'.backup'.length);
        entries.push({
          type: 'file',
          source: path.join(codexHome, withoutBackup),
          backup: file,
        });
      } else {
        entries.push({
          type: 'file',
          source: path.join(codexHome, rel),
          backup: file,
        });
      }
    });
    if (entries.length) {
      return {
        dir,
        manifest: {
          createdAt: path.basename(dir),
          codexHome,
          entries,
          legacyFormat: 'repair_backups-directory',
        },
      };
    }
  }
  return null;
}

function latestLegacySuffixBackup(codexHome) {
  const pattern = /^(?<source>.+)\.(?<timestamp>\d{14})\.(?<suffix>before-provider-lechun|before-history-repair)\.bak$/;
  const candidates = [];
  walkFiles(codexHome, (file) => {
    if (file.includes(`${path.sep}repair_backups${path.sep}`)) return;
    const match = file.match(pattern);
    if (match?.groups?.source) {
      candidates.push({
        timestamp: match.groups.timestamp,
        source: match.groups.source,
        backup: file,
        suffix: match.groups.suffix,
      });
    }
  });
  if (!candidates.length) return null;

  const latestTimestamp = candidates.map((item) => item.timestamp).sort().at(-1);
  const entries = candidates
    .filter((item) => item.timestamp === latestTimestamp)
    .map((item) => ({ type: 'file', source: item.source, backup: item.backup }));

  return {
    dir: `${codexHome}/legacy-suffix-backups/${latestTimestamp}`,
    manifest: {
      createdAt: latestTimestamp,
      codexHome,
      entries,
      legacyFormat: 'timestamp-suffix-bak',
    },
  };
}

function walkFiles(root, visit) {
  if (!fs.existsSync(root)) return;
  const stack = [root];
  while (stack.length) {
    const current = stack.pop();
    for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) stack.push(full);
      else if (entry.isFile()) visit(full);
    }
  }
}

function loadBackup(args) {
  if (args.backupDir) {
    const manifestPath = path.join(args.backupDir, 'manifest.json');
    if (fs.existsSync(manifestPath)) {
      return { dir: args.backupDir, manifest: JSON.parse(fs.readFileSync(manifestPath, 'utf8')) };
    }
    const relEntries = [];
    walkFiles(args.backupDir, (file) => {
      const rel = path.relative(args.backupDir, file);
      if (file.endsWith('.backup')) {
        relEntries.push({ type: 'file', source: path.join(args.codexHome, rel.slice(0, -'.backup'.length)), backup: file });
      } else {
        relEntries.push({ type: 'file', source: path.join(args.codexHome, rel), backup: file });
      }
    });
    if (!relEntries.length) throw new Error(`Missing manifest and no restorable files found: ${args.backupDir}`);
    return { dir: args.backupDir, manifest: { createdAt: path.basename(args.backupDir), codexHome: args.codexHome, entries: relEntries, legacyFormat: 'explicit-directory' } };
  }
  const backups = findManifestBackups(args.codexHome);
  if (backups.length) return backups[0];
  const legacyRepair = latestLegacyRepairBackup(args.codexHome);
  if (legacyRepair) return legacyRepair;
  const legacySuffix = latestLegacySuffixBackup(args.codexHome);
  if (legacySuffix) return legacySuffix;
  throw new Error(`No manifest or legacy backups found under ${args.codexHome}`);
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function createPreRestoreBackup(codexHome, entries) {
  const ts = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14);
  const backupRoot = path.join(codexHome, 'repair_backups', `${ts}-before-restore`);
  const manifestEntries = [];
  ensureDir(backupRoot);

  for (const entry of entries) {
    if (!fs.existsSync(entry.source)) continue;
    const rel = path.relative(codexHome, entry.source);
    if (rel.startsWith('..')) continue;
    const backup = path.join(backupRoot, 'files', rel);
    ensureDir(path.dirname(backup));
    fs.copyFileSync(entry.source, backup);
    manifestEntries.push({ type: 'file', source: entry.source, backup });
  }

  fs.writeFileSync(path.join(backupRoot, 'manifest.json'), JSON.stringify({
    createdAt: new Date().toISOString(),
    codexHome,
    entries: manifestEntries,
  }, null, 2) + '\n');
  return backupRoot;
}

function restoreEntry(entry) {
  if (!entry.source || !entry.backup) throw new Error(`Invalid manifest entry: ${JSON.stringify(entry)}`);
  if (!fs.existsSync(entry.backup)) throw new Error(`Backup file missing: ${entry.backup}`);
  ensureDir(path.dirname(entry.source));
  fs.copyFileSync(entry.backup, entry.source);
}

async function confirmRestore(backupDir, args) {
  if (args.yes) return;
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const answer = await rl.question(`Restore from ${backupDir}? Type "RESTORE" to continue: `);
  rl.close();
  if (answer !== 'RESTORE') throw new Error('Aborted by user');
}

function printJson(value) {
  console.log(JSON.stringify(value, null, 2));
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    process.stdout.write(usage());
    return;
  }
  if (!fs.existsSync(args.codexHome)) throw new Error(`Codex home does not exist: ${args.codexHome}`);

  const backup = loadBackup(args);
  const entries = Array.isArray(backup.manifest.entries) ? backup.manifest.entries : [];
  const plan = {
    mode: args.apply ? 'apply' : 'dry-run',
    codexHome: args.codexHome,
    backupDir: backup.dir,
    createdAt: backup.manifest.createdAt || null,
    entries: entries.map((entry) => ({ type: entry.type, source: entry.source, backup: entry.backup })),
    notes: [
      'Default dry-run does not change files.',
      'Apply mode creates a before-restore backup first.',
      'Close Codex Desktop before restoring.',
    ],
  };

  if (!args.apply) {
    printJson(plan);
    return;
  }

  await confirmRestore(backup.dir, args);
  const preRestoreBackup = createPreRestoreBackup(args.codexHome, entries);
  for (const entry of entries) restoreEntry(entry);
  printJson({ restored: entries.length, backupDir: backup.dir, preRestoreBackup });
}

main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
