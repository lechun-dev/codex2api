@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "SCRIPT_PATH=%SCRIPT_DIR%scripts\codex-lechun-provider.ps1"

if not exist "%SCRIPT_PATH%" (
    echo Script not found:
    echo %SCRIPT_PATH%
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_PATH%"
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if not "%EXIT_CODE%"=="0" (
    echo Failed with exit code %EXIT_CODE%.
) else (
    echo Finished successfully.
)
echo Restart Codex Desktop after this window closes.
pause
exit /b %EXIT_CODE%
