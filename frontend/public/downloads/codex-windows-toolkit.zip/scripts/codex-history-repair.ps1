param(
    [string]$ProviderName,
    [string]$CodexHome = (Join-Path $env:USERPROFILE ".codex"),
    [switch]$SkipSqlite,
    [switch]$SkipRollouts,
    [switch]$SkipIndexRebuild
)

$ErrorActionPreference = "Stop"

$Timestamp = Get-Date -Format "yyyyMMddHHmmss"
$BackupSuffix = "before-history-repair"
$AuthPath = Join-Path $CodexHome "auth.json"
$ConfigPath = Join-Path $CodexHome "config.toml"

function Backup-File {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (Test-Path -LiteralPath $Path) {
        $backupPath = "$Path.$Timestamp.$BackupSuffix.bak"
        Copy-Item -LiteralPath $Path -Destination $backupPath -Force
        Write-Host "Backup: $backupPath"
    }
}

function Backup-SqliteWithSidecars {
    param([Parameter(Mandatory = $true)][string]$Path)

    foreach ($candidate in @($Path, "$Path-shm", "$Path-wal")) {
        Backup-File -Path $candidate
    }
}

function Write-Utf8NoBomLines {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string[]]$Lines
    )

    $utf8 = [System.Text.UTF8Encoding]::new($false)
    [System.IO.File]::WriteAllLines($Path, $Lines, $utf8)
}

function Write-Utf8NoBomText {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Text
    )

    $utf8 = [System.Text.UTF8Encoding]::new($false)
    [System.IO.File]::WriteAllText($Path, $Text, $utf8)
}

function Get-ConfiguredProvider {
    if (-not (Test-Path -LiteralPath $ConfigPath)) {
        return $null
    }

    $content = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8
    $match = [regex]::Match($content, '(?m)^\s*model_provider\s*=\s*"([^"]+)"')
    if ($match.Success) {
        return $match.Groups[1].Value
    }

    return $null
}

function Ensure-ConfigHistory {
    if (-not (Test-Path -LiteralPath $ConfigPath)) {
        Write-Warning "config.toml not found, skipped config repair: $ConfigPath"
        return
    }

    Backup-File -Path $ConfigPath
    $content = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8
    $content = [regex]::Replace($content, '(?m)^\s*disable_response_storage\s*=\s*true\s*(?:#.*)?\r?\n?', '')

    $historyMatch = [regex]::Match($content, '(?ms)^\[history\]\r?\n.*?(?=^\[|\z)')
    if ($historyMatch.Success) {
        $section = $historyMatch.Value
        if ($section -match '(?m)^persistence\s*=') {
            $updatedSection = [regex]::Replace($section, '(?m)^persistence\s*=.*$', 'persistence = "save-all"', 1)
        } else {
            $updatedSection = $section.TrimEnd() + "`r`npersistence = `"save-all`"`r`n"
        }
        $content = $content.Remove($historyMatch.Index, $historyMatch.Length).Insert($historyMatch.Index, $updatedSection)
    } else {
        $content = $content.TrimEnd() + "`r`n`r`n[history]`r`npersistence = `"save-all`"`r`n"
    }

    Write-Utf8NoBomText -Path $ConfigPath -Text ($content.TrimEnd() + "`r`n")
    Write-Host "Config history persistence repaired: $ConfigPath"
}

function Update-JsonlSessionProvider {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    Backup-File -Path $Path

    $changed = $false
    $updated = foreach ($line in [System.IO.File]::ReadLines($Path)) {
        if ($line -notmatch '"session_meta"') {
            $line
            continue
        }

        if ($line -match '"model_provider"\s*:') {
            $newLine = [regex]::Replace($line, '"model_provider"\s*:\s*"[^"]*"', "`"model_provider`":`"$ProviderName`"", 1)
            if ($newLine -ne $line) {
                $changed = $true
            }
            $newLine
            continue
        }

        try {
            $obj = $line | ConvertFrom-Json
            if ($obj.type -eq "session_meta" -and $null -ne $obj.payload) {
                if ($obj.payload.PSObject.Properties.Name -contains "model_provider") {
                    $obj.payload.model_provider = $ProviderName
                } else {
                    $obj.payload | Add-Member -NotePropertyName "model_provider" -NotePropertyValue $ProviderName
                }
                $changed = $true
                $obj | ConvertTo-Json -Compress -Depth 100
            } elseif ($null -ne $obj.session_meta) {
                if ($obj.session_meta.PSObject.Properties.Name -contains "model_provider") {
                    $obj.session_meta.model_provider = $ProviderName
                } else {
                    $obj.session_meta | Add-Member -NotePropertyName "model_provider" -NotePropertyValue $ProviderName
                }
                $changed = $true
                $obj | ConvertTo-Json -Compress -Depth 100
            } else {
                $line
            }
        } catch {
            $line
        }
    }

    if ($changed) {
        Write-Utf8NoBomLines -Path $Path -Lines $updated
        Write-Host "Updated rollout provider: $Path"
    } else {
        Write-Host "No provider change needed: $Path"
    }
}

function Get-ExistingIndexNames {
    $indexPath = Join-Path $CodexHome "session_index.jsonl"
    $names = @{}

    if (-not (Test-Path -LiteralPath $indexPath)) {
        return $names
    }

    foreach ($line in [System.IO.File]::ReadLines($indexPath)) {
        if ([string]::IsNullOrWhiteSpace($line)) {
            continue
        }

        try {
            $obj = $line | ConvertFrom-Json
            if ($obj.id -and $obj.thread_name) {
                $names[$obj.id] = [string]$obj.thread_name
            }
        } catch {
        }
    }

    return $names
}

function Get-ShortTitle {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return $null
    }

    $title = ($Text -replace '\s+', ' ').Trim()
    if ($title.Length -gt 64) {
        return $title.Substring(0, 64)
    }

    return $title
}

function Read-RolloutSummary {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [hashtable]$ExistingNames
    )

    $id = $null
    $createdAt = $null
    $updatedAt = $null
    $title = $null

    foreach ($line in [System.IO.File]::ReadLines($Path)) {
        if ($line -match '"timestamp"\s*:\s*"([^"]+)"') {
            $ts = $matches[1]
            if (-not $updatedAt -or $ts -gt $updatedAt) {
                $updatedAt = $ts
            }
        }

        if (-not $id -and $line -match '"session_meta"') {
            try {
                $obj = $line | ConvertFrom-Json
                if ($obj.type -eq "session_meta" -and $null -ne $obj.payload) {
                    $id = [string]$obj.payload.id
                    $createdAt = [string]$obj.payload.timestamp
                } elseif ($null -ne $obj.session_meta) {
                    $id = [string]$obj.session_meta.id
                    $createdAt = [string]$obj.session_meta.timestamp
                }
            } catch {
            }
        }

        if (-not $title -and ($line -match '"user_message"' -or $line -match '"role"\s*:\s*"user"')) {
            try {
                $obj = $line | ConvertFrom-Json
                if ($obj.type -eq "event_msg" -and $obj.payload.type -eq "user_message") {
                    $title = Get-ShortTitle -Text ([string]$obj.payload.message)
                } elseif ($obj.type -eq "response_item" -and $obj.payload.role -eq "user") {
                    foreach ($item in @($obj.payload.content)) {
                        if ($item.text) {
                            $title = Get-ShortTitle -Text ([string]$item.text)
                            break
                        }
                        if ($item.input_text) {
                            $title = Get-ShortTitle -Text ([string]$item.input_text)
                            break
                        }
                    }
                }
            } catch {
            }
        }
    }

    if (-not $id) {
        return $null
    }

    if ($ExistingNames.ContainsKey($id)) {
        $title = $ExistingNames[$id]
    }

    if (-not $title) {
        $title = "Recovered thread $($id.Substring(0, [Math]::Min(8, $id.Length)))"
    }

    if (-not $updatedAt) {
        $updatedAt = if ($createdAt) { $createdAt } else { (Get-Item -LiteralPath $Path).LastWriteTimeUtc.ToString("o") }
    }

    return [pscustomobject]@{
        id = $id
        thread_name = $title
        updated_at = $updatedAt
    }
}

function Rebuild-SessionIndex {
    $indexPath = Join-Path $CodexHome "session_index.jsonl"
    $existingNames = Get-ExistingIndexNames
    $recordsById = @{}
    $roots = @(
        (Join-Path $CodexHome "sessions"),
        (Join-Path $CodexHome "archived_sessions")
    )

    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root)) {
            continue
        }

        Get-ChildItem -LiteralPath $root -Recurse -File -Filter "*.jsonl" -ErrorAction SilentlyContinue | ForEach-Object {
            $summary = Read-RolloutSummary -Path $_.FullName -ExistingNames $existingNames
            if ($null -ne $summary) {
                $current = $recordsById[$summary.id]
                if ($null -eq $current -or $summary.updated_at -gt $current.updated_at) {
                    $recordsById[$summary.id] = $summary
                }
            }
        }
    }

    if ($recordsById.Count -eq 0) {
        Write-Warning "No rollout sessions found, skipped session_index rebuild."
        return
    }

    Backup-File -Path $indexPath

    $lines = $recordsById.Values |
        Sort-Object updated_at |
        ForEach-Object { $_ | ConvertTo-Json -Compress -Depth 10 }

    Write-Utf8NoBomLines -Path $indexPath -Lines @($lines)
    Write-Host "Rebuilt session index: $indexPath ($($recordsById.Count) threads)"
}

function Find-Sqlite {
    $bundled = Join-Path (Split-Path -Parent $PSScriptRoot) "tools\sqlite3.exe"
    $candidates = @($bundled, "sqlite3")
    $localAppData = $env:LOCALAPPDATA
    if ($localAppData) {
        $candidates += Join-Path $localAppData "Microsoft\WinGet\Packages\SQLite.SQLite_Microsoft.Winget.Source_8wekyb3d8bbwe\sqlite3.exe"
    }

    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) {
            return $candidate
        }

        try {
            $cmd = Get-Command $candidate -ErrorAction Stop
            return $cmd.Source
        } catch {
        }
    }

    return $null
}

function Invoke-PythonSqliteUpdate {
    param([Parameter(Mandatory = $true)][string]$Path)

    $pythonScript = @'
import sqlite3
import sys

path = sys.argv[1]
provider = sys.argv[2]

conn = sqlite3.connect(path)
try:
    table = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='threads'").fetchone()
    if not table:
        print("NO_THREADS_TABLE")
        sys.exit(2)

    columns = [row[1] for row in conn.execute("PRAGMA table_info(threads)").fetchall()]
    if "model_provider" not in columns:
        print("NO_MODEL_PROVIDER_COLUMN")
        sys.exit(3)

    conn.execute("UPDATE threads SET model_provider = ? WHERE model_provider IS NULL OR model_provider <> ?", (provider, provider))
    conn.commit()
    print(f"UPDATED_ROWS={conn.total_changes}")
finally:
    conn.close()
'@

    $tempScript = Join-Path ([System.IO.Path]::GetTempPath()) "codex-history-repair-sqlite-$Timestamp.py"
    Write-Utf8NoBomText -Path $tempScript -Text $pythonScript

    $commands = @(
        @{ Exe = "python"; Args = @() },
        @{ Exe = "py"; Args = @("-3") }
    )

    foreach ($command in $commands) {
        try {
            $resolved = Get-Command $command.Exe -ErrorAction Stop
        } catch {
            continue
        }

        & $resolved.Source @($command.Args) $tempScript $Path $ProviderName
        if ($LASTEXITCODE -eq 0) {
            Remove-Item -LiteralPath $tempScript -Force -ErrorAction SilentlyContinue
            return $true
        }
    }

    Remove-Item -LiteralPath $tempScript -Force -ErrorAction SilentlyContinue
    return $false
}

function Update-StateDbProvider {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    $sqlite = Find-Sqlite
    if (-not $sqlite) {
        Backup-SqliteWithSidecars -Path $Path
        if (Invoke-PythonSqliteUpdate -Path $Path) {
            Write-Host "Updated SQLite provider with Python sqlite3: $Path"
            return
        }

        Write-Warning "sqlite3 and Python sqlite3 were not found, skipped DB provider repair: $Path"
        Write-Warning "The toolkit should include tools\sqlite3.exe. Please use the latest full Windows zip and run this repair again."
        return
    }

    $table = & $sqlite $Path "SELECT name FROM sqlite_master WHERE type='table' AND name='threads';"
    if ($LASTEXITCODE -ne 0 -or $table -ne "threads") {
        Write-Warning "No threads table found, skipped DB provider repair: $Path"
        return
    }

    $columnCount = & $sqlite $Path "SELECT COUNT(*) FROM pragma_table_info('threads') WHERE name='model_provider';"
    if ($LASTEXITCODE -ne 0 -or $columnCount -eq "0") {
        Write-Warning "No model_provider column found, skipped DB provider repair: $Path"
        return
    }

    Backup-SqliteWithSidecars -Path $Path
    $sqlProvider = $ProviderName.Replace("'", "''")
    & $sqlite $Path "UPDATE threads SET model_provider = '$sqlProvider';"
    if ($LASTEXITCODE -ne 0) {
        throw "sqlite3 failed while updating $Path"
    }

    Write-Host "Updated SQLite provider: $Path"
}

if (-not (Test-Path -LiteralPath $CodexHome)) {
    throw "Codex home not found: $CodexHome"
}

$authBefore = $null
if (Test-Path -LiteralPath $AuthPath) {
    $authBefore = Get-Item -LiteralPath $AuthPath | Select-Object Length, LastWriteTimeUtc
}

if ([string]::IsNullOrWhiteSpace($ProviderName)) {
    $detected = Get-ConfiguredProvider
    if ($detected) {
        $answer = Read-Host "Detected provider '$detected'. Press Enter to use it, or type another provider"
        $ProviderName = if ([string]::IsNullOrWhiteSpace($answer)) { $detected } else { $answer.Trim() }
    } else {
        $ProviderName = Read-Host "Enter current model_provider name, for example lechun or custom"
    }
}

if ([string]::IsNullOrWhiteSpace($ProviderName)) {
    throw "ProviderName cannot be empty."
}

Write-Host "Codex home: $CodexHome"
Write-Host "Target provider: $ProviderName"
Write-Host ""
Write-Host "Close Codex Desktop before continuing."
$confirm = Read-Host "Type REPAIR to continue"
if ($confirm -ne "REPAIR") {
    Write-Host "Canceled."
    exit 0
}

Ensure-ConfigHistory

if (-not $SkipRollouts) {
    Update-JsonlSessionProvider -Path (Join-Path $CodexHome "session_index.jsonl")

    foreach ($root in @((Join-Path $CodexHome "sessions"), (Join-Path $CodexHome "archived_sessions"))) {
        if (Test-Path -LiteralPath $root) {
            Get-ChildItem -LiteralPath $root -Recurse -File -Filter "*.jsonl" -ErrorAction SilentlyContinue |
                ForEach-Object { Update-JsonlSessionProvider -Path $_.FullName }
        }
    }
}

if (-not $SkipIndexRebuild) {
    Rebuild-SessionIndex
}

if (-not $SkipSqlite) {
    Update-StateDbProvider -Path (Join-Path $CodexHome "state_5.sqlite")
    Update-StateDbProvider -Path (Join-Path $CodexHome "sqlite\state_5.sqlite")
}

if ($null -ne $authBefore -and (Test-Path -LiteralPath $AuthPath)) {
    $authAfter = Get-Item -LiteralPath $AuthPath | Select-Object Length, LastWriteTimeUtc
    if ($authBefore.Length -ne $authAfter.Length -or $authBefore.LastWriteTimeUtc -ne $authAfter.LastWriteTimeUtc) {
        throw "auth.json changed unexpectedly: $AuthPath"
    }
}

Write-Host ""
Write-Host "History repair finished. Restart Codex Desktop."
Write-Host "Backups were created with suffix: $BackupSuffix"
