param(
    [string]$BaseUrl = "https://codexapi.lechun.cc",
    [string]$Model = "gpt-5.5",
    [string]$ReasoningEffort = "high",
    [switch]$SkipHistoryProviderMigration
)

$ErrorActionPreference = "Stop"

$ProviderName = "lechun"
$CodexHome = Join-Path $env:USERPROFILE ".codex"
$ConfigPath = Join-Path $CodexHome "config.toml"
$AuthPath = Join-Path $CodexHome "auth.json"
$Timestamp = Get-Date -Format "yyyyMMddHHmmss"

function Backup-File {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Suffix
    )

    if (Test-Path -LiteralPath $Path) {
        $BackupPath = "$Path.$Timestamp.$Suffix.bak"
        Copy-Item -LiteralPath $Path -Destination $BackupPath -Force
        Write-Host "Backup: $BackupPath"
    }
}

function Remove-TomlSection {
    param(
        [Parameter(Mandatory = $true)][string]$Content,
        [Parameter(Mandatory = $true)][string]$SectionName
    )

    $escaped = [regex]::Escape($SectionName)
    $pattern = "(?ms)^\[$escaped\]\r?\n.*?(?=^\[|\z)"
    return [regex]::Replace($Content, $pattern, "")
}

function Set-TopLevelTomlValue {
    param(
        [Parameter(Mandatory = $true)][string]$Content,
        [Parameter(Mandatory = $true)][string]$Key,
        [Parameter(Mandatory = $true)][string]$Value
    )

    $escaped = [regex]::Escape($Key)
    $line = "$Key = `"$Value`""

    if ($Content -match "(?m)^$escaped\s*=") {
        return [regex]::Replace($Content, "(?m)^$escaped\s*=.*$", $line, 1)
    }

    $firstSection = [regex]::Match($Content, "(?m)^\[")
    if ($firstSection.Success) {
        return $Content.Insert($firstSection.Index, "$line`r`n")
    }

    if ([string]::IsNullOrWhiteSpace($Content)) {
        return "$line`r`n"
    }

    return $Content.TrimEnd() + "`r`n$line`r`n"
}

function Ensure-HistorySaveAll {
    param([Parameter(Mandatory = $true)][string]$Content)

    $historyMatch = [regex]::Match($Content, "(?ms)^\[history\]\r?\n.*?(?=^\[|\z)")
    if ($historyMatch.Success) {
        $section = $historyMatch.Value
        if ($section -match "(?m)^persistence\s*=") {
            $updatedSection = [regex]::Replace($section, "(?m)^persistence\s*=.*$", 'persistence = "save-all"', 1)
        } else {
            $updatedSection = $section.TrimEnd() + "`r`npersistence = `"save-all`"`r`n"
        }

        return $Content.Remove($historyMatch.Index, $historyMatch.Length).Insert($historyMatch.Index, $updatedSection)
    }

    return $Content.TrimEnd() + "`r`n`r`n[history]`r`npersistence = `"save-all`"`r`n"
}

function Update-SessionMetaProvider {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    Backup-File -Path $Path -Suffix "before-provider-lechun"

    $lines = Get-Content -LiteralPath $Path -Encoding UTF8
    $updated = foreach ($line in $lines) {
        if ([string]::IsNullOrWhiteSpace($line)) {
            $line
            continue
        }

        try {
            $obj = $line | ConvertFrom-Json
            if ($null -ne $obj.session_meta -and $obj.session_meta.PSObject.Properties.Name -contains "model_provider") {
                $obj.session_meta.model_provider = $ProviderName
                $obj | ConvertTo-Json -Compress -Depth 50
            } else {
                $line
            }
        } catch {
            $line
        }
    }

    Set-Content -LiteralPath $Path -Value $updated -Encoding UTF8
    Write-Host "Updated session meta provider: $Path"
}

function Update-StateDbProvider {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    $bundledSqlite = Join-Path (Split-Path -Parent $PSScriptRoot) "tools\sqlite3.exe"
    $sqliteCandidates = @(
        $bundledSqlite,
        "sqlite3",
        (Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Packages\SQLite.SQLite_Microsoft.Winget.Source_8wekyb3d8bbwe\sqlite3.exe")
    )

    $sqlite = $null
    foreach ($candidate in $sqliteCandidates) {
        if (Test-Path -LiteralPath $candidate) {
            $sqlite = $candidate
            break
        }

        try {
            $cmd = Get-Command $candidate -ErrorAction Stop
            $sqlite = $cmd.Source
            break
        } catch {
        }
    }

    if ($null -eq $sqlite) {
        Write-Warning "sqlite3 not found, skipped DB provider migration: $Path"
        return
    }

    Backup-File -Path $Path -Suffix "before-provider-lechun"
    $sqlProvider = $ProviderName.Replace("'", "''")
    & $sqlite $Path "UPDATE threads SET model_provider = '$sqlProvider';"
    if ($LASTEXITCODE -ne 0) {
        throw "sqlite3 failed while updating $Path"
    }

    Write-Host "Updated SQLite provider: $Path"
}

if (-not (Test-Path -LiteralPath $CodexHome)) {
    throw "Codex home not found: $CodexHome"
}

if (-not (Test-Path -LiteralPath $ConfigPath)) {
    throw "Config not found: $ConfigPath"
}

$authBefore = $null
if (Test-Path -LiteralPath $AuthPath) {
    $authBefore = Get-Item -LiteralPath $AuthPath | Select-Object FullName, Length, LastWriteTimeUtc
}

$secureKey = Read-Host "Enter Lechun API key" -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
try {
    $ApiKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
}

if ([string]::IsNullOrWhiteSpace($ApiKey)) {
    throw "API key cannot be empty."
}

Backup-File -Path $ConfigPath -Suffix "before-provider-lechun"

$content = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8
$content = Remove-TomlSection -Content $content -SectionName "model_providers.$ProviderName"
$content = Set-TopLevelTomlValue -Content $content -Key "model_provider" -Value $ProviderName
$content = Set-TopLevelTomlValue -Content $content -Key "model" -Value $Model
$content = Set-TopLevelTomlValue -Content $content -Key "model_reasoning_effort" -Value $ReasoningEffort
$content = Ensure-HistorySaveAll -Content $content

$providerBlock = @"

[model_providers.$ProviderName]
name = "$ProviderName"
wire_api = "responses"
requires_openai_auth = true
base_url = "$BaseUrl"
experimental_bearer_token = "$ApiKey"
"@

$content = $content.TrimEnd() + "`r`n" + $providerBlock.TrimStart() + "`r`n"
Set-Content -LiteralPath $ConfigPath -Value $content -Encoding UTF8
Write-Host "Updated config: $ConfigPath"

if (-not $SkipHistoryProviderMigration) {
    Update-SessionMetaProvider -Path (Join-Path $CodexHome "session_index.jsonl")

    Get-ChildItem -LiteralPath (Join-Path $CodexHome "sessions") -Recurse -Filter "*.jsonl" -ErrorAction SilentlyContinue |
        ForEach-Object { Update-SessionMetaProvider -Path $_.FullName }

    Get-ChildItem -LiteralPath (Join-Path $CodexHome "archived_sessions") -Recurse -Filter "*.jsonl" -ErrorAction SilentlyContinue |
        ForEach-Object { Update-SessionMetaProvider -Path $_.FullName }

    Update-StateDbProvider -Path (Join-Path $CodexHome "state_5.sqlite")
    Update-StateDbProvider -Path (Join-Path $CodexHome "sqlite\state_5.sqlite")
}

if ($null -ne $authBefore -and (Test-Path -LiteralPath $AuthPath)) {
    $authAfter = Get-Item -LiteralPath $AuthPath | Select-Object FullName, Length, LastWriteTimeUtc
    if ($authBefore.Length -ne $authAfter.Length -or $authBefore.LastWriteTimeUtc -ne $authAfter.LastWriteTimeUtc) {
        throw "auth.json changed unexpectedly: $AuthPath"
    }
}

Write-Host ""
Write-Host "Done. Provider name is now '$ProviderName'."
Write-Host "Restart Codex Desktop after running this script."
Write-Host "Do not share config.toml because it now contains your API key."
