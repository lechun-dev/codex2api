param(
    [switch]$ConfigOnly
)

$ErrorActionPreference = "Stop"

$CodexHome = Join-Path $env:USERPROFILE ".codex"
$AuthPath = Join-Path $CodexHome "auth.json"
$Timestamp = Get-Date -Format "yyyyMMddHHmmss"
$BackupSuffix = "before-provider-lechun"
$RestoreSuffix = "before-restore-lechun"

function Backup-CurrentFile {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (Test-Path -LiteralPath $Path) {
        $backupPath = "$Path.$Timestamp.$RestoreSuffix.bak"
        Copy-Item -LiteralPath $Path -Destination $backupPath -Force
        Write-Host "Current backup: $backupPath"
    }
}

function Get-OriginalPathFromBackup {
    param([Parameter(Mandatory = $true)][string]$BackupPath)

    $pattern = "^(?<path>.+)\.(?<timestamp>\d{14})\.$BackupSuffix\.bak$"
    $match = [regex]::Match($BackupPath, $pattern)
    if (-not $match.Success) {
        return $null
    }

    return [pscustomobject]@{
        OriginalPath = $match.Groups["path"].Value
        Timestamp = $match.Groups["timestamp"].Value
        BackupPath = $BackupPath
    }
}

if (-not (Test-Path -LiteralPath $CodexHome)) {
    throw "Codex home not found: $CodexHome"
}

$authBefore = $null
if (Test-Path -LiteralPath $AuthPath) {
    $authBefore = Get-Item -LiteralPath $AuthPath | Select-Object FullName, Length, LastWriteTimeUtc
}

$candidateFiles = if ($ConfigOnly) {
    Get-ChildItem -LiteralPath $CodexHome -File -Filter "config.toml.*.$BackupSuffix.bak" -ErrorAction SilentlyContinue
} else {
    Get-ChildItem -LiteralPath $CodexHome -Recurse -File -Filter "*.$BackupSuffix.bak" -ErrorAction SilentlyContinue
}

$backups = @(
    foreach ($file in $candidateFiles) {
        Get-OriginalPathFromBackup -BackupPath $file.FullName
    }
) | Where-Object { $null -ne $_ }

if (-not $backups -or $backups.Count -eq 0) {
    throw "No backups found with suffix: $BackupSuffix"
}

$latestByOriginal = $backups |
    Group-Object OriginalPath |
    ForEach-Object {
        $_.Group | Sort-Object Timestamp -Descending | Select-Object -First 1
    } |
    Sort-Object OriginalPath

Write-Host "The following files will be restored from latest backups:"
$latestByOriginal | ForEach-Object {
    Write-Host "  $($_.OriginalPath)"
    Write-Host "    <- $($_.BackupPath)"
}
Write-Host ""

$confirm = Read-Host "Type RESTORE to continue"
if ($confirm -ne "RESTORE") {
    Write-Host "Canceled."
    exit 0
}

foreach ($item in $latestByOriginal) {
    $parent = Split-Path -Parent $item.OriginalPath
    if (-not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Path $parent -Force | Out-Null
    }

    Backup-CurrentFile -Path $item.OriginalPath
    Copy-Item -LiteralPath $item.BackupPath -Destination $item.OriginalPath -Force
    Write-Host "Restored: $($item.OriginalPath)"
}

if ($null -ne $authBefore -and (Test-Path -LiteralPath $AuthPath)) {
    $authAfter = Get-Item -LiteralPath $AuthPath | Select-Object FullName, Length, LastWriteTimeUtc
    if ($authBefore.Length -ne $authAfter.Length -or $authBefore.LastWriteTimeUtc -ne $authAfter.LastWriteTimeUtc) {
        throw "auth.json changed unexpectedly: $AuthPath"
    }
}

Write-Host ""
Write-Host "Restore finished. Restart Codex Desktop."
